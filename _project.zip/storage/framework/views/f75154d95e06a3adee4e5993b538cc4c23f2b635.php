<?php $__env->startSection('title'); ?> About <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('blog.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\it-news\_project\resources\views/blog/about.blade.php ENDPATH**/ ?>