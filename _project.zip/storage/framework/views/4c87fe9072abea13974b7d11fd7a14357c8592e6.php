<li class="menu-spacer"></li>
<?php /**PATH J:\it-news\_project\resources\views/components/menu-spacer.blade.php ENDPATH**/ ?>