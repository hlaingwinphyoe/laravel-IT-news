<table class="table table-hover border-0">
    <thead>
    <tr>
        <th>#</th>
        <th>Title</th>
        <th>Owner</th>
        <th>Control</th>
        <th>Time</th>
    </tr>
    </thead>
    <tbody>
    

    <?php $__currentLoopData = \App\Category::with('user')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($category->id); ?></td>
            <td><?php echo e($category->title); ?></td>
            <td><?php echo e($category->user->name); ?></td>
            <td>
                <a href="<?php echo e(route("category.edit",$category->id)); ?>" title="Edit">
                    <i class="fas fa-pen text-warning fa-fw mr-2"></i>
                </a>
                <form action="<?php echo e(route("category.destroy",$category->id)); ?>" class="d-inline-block" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("delete"); ?>
                    <button style="padding: 0;background: none;border: none;outline: none;" title="Delete" onclick="return confirm('Are you sure? You want to delete \'<?php echo e($category->title); ?>\' category')">
                        <i class="fas fa-trash text-danger fa-fw"></i>
                    </button>
                </form>
            </td>
            <td><?php echo e($category->created_at->format("d M, Y")); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\User\PhpstormProjects\laravel\it-news\resources\views/category/lists.blade.php ENDPATH**/ ?>