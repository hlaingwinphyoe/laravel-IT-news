<table class="table table-hover border-0">
    <thead>
    <tr>
        <th>#</th>
        <th>Title</th>
        <th>Owner</th>
        <th>Control</th>
        <th>Time</th>
    </tr>
    </thead>
    <tbody>
    

    <?php $__empty_1 = true; $__currentLoopData = \App\Category::with('user')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($category->id); ?></td>
            <td><?php echo e($category->title); ?></td>
            <td><?php echo e($category->user->name); ?></td>
            <td>
                <a href="<?php echo e(route("category.edit",$category->id)); ?>" title="Edit" class="text-decoration-none">
                    <i class="fas fa-pen text-warning fa-fw mr-2"></i>
                </a>
                <form action="<?php echo e(route("category.destroy",$category->id)); ?>" class="d-inline-block text-decoration-none" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("delete"); ?>
                    <button style="padding: 0;background: none;border: none;outline: none;" title="Delete" onclick="return confirm('Are you sure? You want to delete \'<?php echo e($category->title); ?>\' category')">
                        <i class="fas fa-trash text-danger fa-fw"></i>
                    </button>
                </form>
            </td>
            <td><?php echo e($category->created_at->format("d M, Y")); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="5" class="text-center">There's no category</td>
        </tr>

    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH J:\it-news\resources\views/category/lists.blade.php ENDPATH**/ ?>