<div class="col-12 col-lg-3 col-xl-2 vh-100 sidebar">
    <div class="d-flex justify-content-between align-items-center py-2 mt-3 nav-brand">
        <div class="d-flex align-items-center">
            <img src="<?php echo e(asset(\App\Base::$logo)); ?>" class="w-50" alt="">
        </div>
        <button class="hide-sidebar-btn btn btn-light d-block d-lg-none">
            <i class="feather-x text-primary" style="font-size: 2em;"></i>
        </button>
    </div>
    <div class="nav-menu">
        <ul>
             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['name' => 'Home','class' => 'feather-home','link' => ''.e(route('home')).'']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['title' => 'Item Management']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['name' => 'Create Item','class' => 'feather-plus']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['name' => 'Items List','class' => 'feather-list','counter' => '50']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['title' => 'Article Manager']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['name' => 'Manage Category','class' => 'feather-layers','link' => ''.e(route('category.index')).'']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['name' => 'Create Article','class' => 'feather-plus','link' => ''.e(route('article.create')).'']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['name' => 'Articles List','class' => 'feather-list','link' => ''.e(route('article.index')).'']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


             <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['title' => 'User Profile']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['name' => 'Your Profile','class' => 'feather-user','link' => ''.e(route('profile')).'']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['name' => 'Change Password','class' => 'feather-lock','link' => ''.e(route('profile.edit.password')).'']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['name' => 'Update Info','class' => 'feather-message-square','link' => ''.e(route('profile.edit.name.email')).'']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
             <?php if (isset($component)) { $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuItem::class, ['name' => 'Update Photo','class' => 'feather-image','link' => ''.e(route('profile.edit.photo')).'']); ?>
<?php $component->withName('menu-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3)): ?>
<?php $component = $__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3; ?>
<?php unset($__componentOriginald4a267de86f383005249ca2a9a99cedcc60162e3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

             <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

            <a class="btn btn-outline-primary w-100" href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                Log Out
            </a>

        </ul>
    </div>
</div>
<?php /**PATH J:\it-news\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>