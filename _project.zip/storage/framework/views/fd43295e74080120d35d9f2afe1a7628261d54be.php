<li class="menu-spacer"></li>
<?php /**PATH C:\Users\User\PhpstormProjects\laravel\it-news\resources\views/components/menu-spacer.blade.php ENDPATH**/ ?>