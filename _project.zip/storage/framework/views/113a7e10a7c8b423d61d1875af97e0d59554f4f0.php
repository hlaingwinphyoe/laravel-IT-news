<div class="row">
    <div class="col-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-transparent">
                <li class="breadcrumb-item"><a href="<?php echo e(route("home")); ?>">Home</a></li>
                <?php echo e($slot); ?>

            </ol>
        </nav>
    </div>
</div>
<?php /**PATH C:\Users\User\PhpstormProjects\laravel\it-news\resources\views/components/bread-crumb.blade.php ENDPATH**/ ?>