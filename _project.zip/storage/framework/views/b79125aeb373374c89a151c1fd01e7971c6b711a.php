<li class="menu-item">
    <a href="<?php echo e($link); ?>" class="menu-item-link <?php echo e(Request::url() == $link ? 'active':''); ?>">
        <span class="text-dark">
            <i class="<?php echo e($class); ?> mr-2 fa-fw"></i>
            <?php echo e($name); ?>

        </span>
        <?php if($counter >= 0): ?>
            <span class="badge badge-pill bg-white shadow-sm text-primary"><?php echo e($counter); ?></span>
        <?php endif; ?>
    </a>
</li>
<?php /**PATH J:\it-news\resources\views/components/menu-item.blade.php ENDPATH**/ ?>