<h1>Welcome</h1>
<a href="<?php echo e(route("login")); ?>">Log In</a>
<?php /**PATH C:\Users\User\PhpstormProjects\laravel\front_end\laravel7\resources\views/welcome.blade.php ENDPATH**/ ?>