<li class="menu-title">
    <span><?php echo e($title); ?></span>
</li>
<?php /**PATH J:\it-news\_project\resources\views/components/menu-title.blade.php ENDPATH**/ ?>