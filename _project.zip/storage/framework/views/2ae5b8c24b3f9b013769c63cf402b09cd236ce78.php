<li class="menu-title">
    <span><?php echo e($title); ?></span>
</li>
<?php /**PATH C:\Users\User\PhpstormProjects\laravel\front_end\laravel7\resources\views/components/menu-title.blade.php ENDPATH**/ ?>