<?php $__env->startSection("title"); ?> <?php echo e($article->title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>

    <style>
        .description{
            white-space: pre-line;
        }
    </style>

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.bread-crumb','data' => []]); ?>
<?php $component->withName('bread-crumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route("article.index")); ?>">Articles</a></li>
        <li class="breadcrumb-item active" aria-current="page">Article's Detail</li>
     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <div class="row">
        <div class="col-12 col-lg-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="mb-0">
                        <?php echo e($article->title); ?>

                    </h4>
                    <div class="mt-2">
                        <small class="mr-2 font-weight-bolder">
                            <i class="fas fa-user text-primary"></i>
                            <?php echo e($article->user->name); ?>

                        </small>
                        <small class="mr-2 font-weight-bolder">
                            <i class="feather-layers text-secondary"></i>
                            <?php echo e($article->category->title); ?>

                        </small>
                        <small class="font-weight-bolder">
                            <i class="fas fa-calendar text-success"></i>
                            <?php echo e($article->created_at->format("d M, Y")); ?>

                        </small>
                    </div>
                    <p class="text-black-50 description">
                        <?php echo e($article->description); ?>

                    </p>
                    <hr>
                    <a href="<?php echo e(route("article.edit",$article->id)); ?>" title="Edit" class="text-decoration-none btn btn-outline-warning">
                        <i class="fas fa-pen fa-fw mr-2"></i>
                        Edit
                    </a>
                    <form action="<?php echo e(route("article.destroy",[$article->id,'page' => request()->page])); ?>" class="d-inline-block text-decoration-none" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("delete"); ?>
                        <button class="btn btn-outline-danger" title="Delete" onclick="return confirm('Are you sure? You want to delete \'<?php echo e($article->title); ?>\'')">
                            <i class="fas fa-trash fa-fw"></i>
                            Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH J:\it-news\resources\views/article/show.blade.php ENDPATH**/ ?>