<li class="menu-title">
    <span><?php echo e($title); ?></span>
</li>
<?php /**PATH J:\it-news\resources\views/components/menu-title.blade.php ENDPATH**/ ?>