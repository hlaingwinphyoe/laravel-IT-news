@extends('blog.master')

@section('title') About @stop

@section('content')

@stop
